<?php

return [
    'name' => 'Vacancy'
];
