<?php

return [
    'name' => 'Testimonial'
];
